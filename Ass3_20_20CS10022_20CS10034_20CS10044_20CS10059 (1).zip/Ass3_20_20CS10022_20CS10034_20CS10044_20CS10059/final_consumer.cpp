#include <iostream>
#include <fstream>
#include <cstdlib>
#include <cstring>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <bits/stdc++.h>
using namespace std;

#define MAX_NODES 100005
#define MAX_EDGES 5024
#define N 100005
#define inf 1000000

int dist[N];
int par[N];
set<pair<int, int> > Q;
bool optimize = false;
int graph_version = 0;


// Structure to represent a node in the graph
struct Node 
{
    int id;
    int node_version;
    int num_neighbors;
    int edges[MAX_EDGES];
};

// Structure to represent the graph
struct Graph 
{
    int num_nodes;
    int version;
    struct Node nodes[MAX_NODES];
};


typedef struct {
    int consumer_id;
    int start_node;
    int end_node;
    char* output_file;
} ConsumerConfig;



void dijkstraUtil(Graph* graph, int s)
{
    set<pair<int, int> >::iterator it;
    int i, nn = graph->nodes[s].num_neighbors;

    for (i = 0; i < nn; i++){
        int v = graph->nodes[s].edges[i];
        //cout<< s<< " "<< v<< endl;
        if (dist[s]+1 < dist[v]) {
 
            it = Q.find({ dist[v], v});
            Q.erase(it);
            dist[v] = dist[s] + 1;
            Q.insert({ dist[v], v });

            par[v] = s;
        }
    }
 
    if (Q.size() == 0) {return;}

    it = Q.begin();
    int next = it->second;
    //cout<< it->second<< "   ";
    Q.erase(it);
 
    dijkstraUtil(graph, next);

    return;
}

void dijkstra(Graph* graph, int sources[], int S)
{
    int n = graph->num_nodes;
    int source[n];
 
    for (int i = 0; i < n; i++) source[i] = 0;
    for (int i = 0; i <= S - 1; i++) source[sources[i]] = 1;
    //cout<< graph_version <<  " " << n << endl;
    if(optimize)
    {
        for (int i = 0; i < n; i++)
        {
            if(graph_version > 0)
            {
                if(graph->nodes[i].node_version > graph_version)
                {
                    if (source[i]) {
                        dist[i] = 0;
                        par[i] = i;
                        Q.insert({ 0, i });
                    }
                    else {
                        dist[i] = inf;
                        par[i] = -1;
                        Q.insert({ inf, i });
                    }
                }
            }
            else
            {
                if (source[i]) {
                    dist[i] = 0;
                    par[i] = i;
                    Q.insert({ 0, i });
                }
                else {
                    dist[i] = inf;
                    par[i] = -1;
                    Q.insert({ inf, i });
                }
            }
        }
    }
    else 
    {
        for (int i = 0; i < n; i++) {
            if (source[i]) {
                dist[i] = 0;
                par[i] = i;
                Q.insert({ 0, i });
            }
            else {
                dist[i] = inf;
                par[i] = -1;
                Q.insert({ inf, i });
            }
        }
    }

 
    set<pair<int, int> >::iterator itr;
    itr = Q.begin();

    int start = itr->second;

    dijkstraUtil(graph, start);

    graph_version = graph->version;
    //cout<< graph_version  <<  " " << n << endl;

    /*for (int i = 0; i < n; i++)
        cout << i << " " << dist[i] << endl;*/
}




void* consumer(void* arg) {

    ConsumerConfig* config = (ConsumerConfig*) arg;
    
    pid_t pid = fork();
    if(pid < 0)
    {
        cerr << "Failed to fork child process." << endl;
    }
    else if(pid == 0)
    {
        key_t key = 265;
        int shmid = shmget(key, sizeof(Graph), 0666);

        if (shmid < 0) {
            cerr << "Failed to get shared memory segment." << endl;
            return (void* )1;
        }
        cout<<"Shared memory opened by consumer- successfully"<<endl;

        // Attach shared memory segment
        Graph* graph = (Graph*) shmat(shmid, NULL, 0);
        if ((void*) graph == (void*) -1) {
            cerr << "Failed to attach shared memory segment." << endl;
            return (void* )1;
        }

        /*// Print graph
        for (int i = 0; i < graph->num_nodes; i++) {
            cout << "Node " << graph->nodes[i].id << ": ";
            for (int j=0; j < graph->nodes[i].num_neighbors; j++) {
                cout << graph->nodes[i].edge[j] << " ";
            }
            cout << endl;
        }*/

        cout<<"No. of nodes in graph : "<< graph->num_nodes <<endl;       
        //int cnt = 5;
        while (1) {
            
            int nodes_per_consumer = graph->num_nodes / 10;
            int id = config->consumer_id;
            
            config->start_node = id * nodes_per_consumer;
            config->end_node = (id + 1) * nodes_per_consumer;
            int sn = config->start_node, en = config->end_node, nn = en-sn;
            
            int src[nn];
            for(int i=0; i<nn; i++) src[i]=i+sn;

            

            

            //cout << sn<< " " << en<< endl;
            dijkstra(graph, src, nn);

            cout << "dijkstra done for consumer-" << config->consumer_id<< endl;
            FILE* output = fopen(config->output_file, "a");
            for (int j = 0; j < graph->num_nodes; j++) {

                int k = j;
                
                for( ; k!= par[k]; k = par[k]){
                    
                    if(par[k]==-1) break;
                    fprintf(output, "%d--%d  ", k, par[k]);

                }

                if(par[j]!=-1) fprintf(output, "\t Path :- %d----%d\t Distance:- %d\n", j, k, dist[j]);

            }


            fflush(output);
            fclose(output);
            sleep(30);  // Sleep for 30 seconds before running again
        }
        exit(0);   
    }

    return NULL;
}


int main(int argc, char* argv[])
{   
    // Parse command line arguments
    if (argc > 1 && string(argv[1]) == "-optimize") {
    optimize = true;
    }

    ConsumerConfig configs[10];
    
    for (int i = 0; i < 10; i++) {
        configs[i].consumer_id = i;
        configs[i].output_file = (char* )malloc(sizeof(char) * 256);
        
        if(optimize) sprintf(configs[i].output_file, "o_%d.txt", i);
        else sprintf(configs[i].output_file, "output_%d.txt", i);
        consumer(&configs[i]);
    }

    // Clean up
    for (int i = 0; i < 10; i++) {
        free(configs[i].output_file);
    }

    return 0;
}