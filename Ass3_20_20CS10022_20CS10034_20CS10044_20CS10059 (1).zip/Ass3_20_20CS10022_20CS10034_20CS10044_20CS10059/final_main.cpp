#include <iostream>
#include <fstream>
#include <cstdlib>
#include <cstring>
#include <sys/ipc.h>
#include <sys/shm.h>
using namespace std;

#define MAX_NODES 100005
#define MAX_EDGES 5024

// Structure to represent a node in the graph
struct Node 
{
    int id;
    int node_version;
    int num_neighbors;
    int edges[MAX_EDGES];
};

// Structure to represent the graph
struct Graph 
{
    int num_nodes;
    int version;
    struct Node nodes[MAX_NODES];
};

int main() {


    // Create shared memory segment
  	key_t key = 265;
    int shmid = shmget(key, sizeof(Graph), IPC_CREAT | 0666);

    cout<< sizeof(Graph)<< endl;

    if (shmid < 0) {
        cerr << "Failed to create shared memory segment." << endl;
        return 1;
    }
    cout<<"Shared memory created successfully"<<endl;

    // Attach shared memory segment
    Graph* graph = (Graph*) shmat(shmid, NULL, 0);
    if ((void*) graph == (void*) -1) {
        cerr << "Failed to attach shared memory segment." << endl;
        return 1;
    }
    cout<<"Loading the graph in memory.."<<endl;
    // Initialize graph
    graph->num_nodes = 0;
    graph->version = 0;
    for (int i = 0; i < MAX_NODES; i++) {
        graph->nodes[i].id = -1;
    }

    // Read edges from file and add them to graph
    ifstream infile("facebook_combined.txt");
    if (!infile.is_open()) {
        cerr << "Failed to open input file." << endl;
        return 1;
    }

    int from, to;
    while (infile >> from >> to) {
        // Add edge to graph

        // Check if 'from' node exists
        Node* from_node = NULL;

        if(graph->nodes[from].id == from)
        {
            from_node = &graph->nodes[from];
        }
        if (from_node == NULL) {           
            from_node = &graph->nodes[from];
            from_node->id = from;
            from_node->num_neighbors = 0;
            from_node->node_version = 0;
            graph->num_nodes++;
        }

        // Check if 'to' node exists
        Node* to_node = NULL;

        if(graph->nodes[to].id == to)
        {
            to_node = &graph->nodes[to];
        }
        if (to_node == NULL) {  
            to_node = &graph->nodes[to];
            to_node->id = to;
            to_node->num_neighbors = 0;
            to_node->node_version = 0;
            graph->num_nodes++;
        }

    // Add edge to 'from' node's adjacency list
    from_node->edges[from_node->num_neighbors] = to;
    from_node->num_neighbors++;
    to_node->edges[to_node->num_neighbors] = from;
    to_node->num_neighbors++;
}
cout<<"Graph loaded onto memory succesfully"<<endl;
// Print graph
for (int i = 0; i < graph->num_nodes; i++) {
    cout << "Node " << i<< " "<< graph->nodes[i].id<< " "<< graph->nodes[i].num_neighbors << ": ";
    for (int j=0; j < graph->nodes[i].num_neighbors; j++) {
        cout << graph->nodes[i].edges[j]<< " ";
    }
    cout << endl;
}

cout<<"No. of nodes in graph : "<<graph->num_nodes<<endl;

    if (shmdt(graph) == -1) {
        cerr << "Failed to detach shared memory segment." << endl;
        return 1;
    }
    cout<<"Graph detached from memory."<<endl;
    // Remove shared memory segment
    /*if (shmctl(shmid, IPC_RMID, NULL) == -1) {
        cerr << "Failed to remove shared memory segment." << endl;
        return 1;
    }
    cout<<"Removed the shared memory segment."<<endl;*/

return 0;
}
