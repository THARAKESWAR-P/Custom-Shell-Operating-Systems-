#include <iostream>
#include <fstream>
#include <cstdlib>
#include <cstring>
#include <unistd.h>
#include <sys/ipc.h>
#include <sys/shm.h>
using namespace std;

#define MAX_NODES 100005
#define MAX_EDGES 5024

// Structure to represent a node in the graph
struct Node 
{
    int id;
    int node_version;
    int num_neighbors;
    int edges[MAX_EDGES];
};

// Structure to represent the graph
struct Graph 
{
    int num_nodes;
    int version;
    struct Node nodes[MAX_NODES];
};

int main()
{
    
    key_t key = 265;
    int shmid = shmget(key, sizeof(Graph), 0666);

    cout<< sizeof(Graph)<< endl;

    if (shmid < 0) {
        cerr << "Failed to create shared memory segment." << endl;
        return 1;
    }
    cout<<"Shared memory created successfully"<<endl;

    // Attach shared memory segment
    Graph* graph = (Graph*) shmat(shmid, NULL, 0);
    if ((void*) graph == (void*) -1) {
        cerr << "Failed to attach shared memory segment." << endl;
        return 1;
    }
   

    srand(time(nullptr));
    int degrees[MAX_NODES], probabilities[MAX_NODES], connections[50];
    while(1)
    {
        /*for (int i = 0; i < graph->num_nodes; i++) {
            cout << "Node " << graph->nodes[i].id << ": ";
            for (int j=0; j < graph->nodes[i].num_neighbors; j++) {
                cout << graph->nodes[i].edges[j] << " ";
            }
            cout << endl;
        }*/
        cout<< "No. of nodes in graph : "<< graph->num_nodes<<endl;
        sleep(50);

        int m = rand() % 21 + 10; // choose number of new nodes in the range [10, 30]
        int n = graph->num_nodes; // get current number of nodes
        int total_degree = 0;
        for (int i = 0; i < n; i++) {
            degrees[i] = graph->nodes[i].num_neighbors;
            total_degree += degrees[i];
        }
        probabilities[0] = degrees[0];
        for (int i = 1; i < n; i++) {
            probabilities[i] = probabilities[i - 1] + degrees[i];
        }

        graph->version++;
        for (int i = n; i < n + m; i++) { // add new nodes
            graph->nodes[i].id = i;
            graph->nodes[i].num_neighbors = 0;
            graph->nodes[i].node_version = graph->version;
            int k = rand() % 20 + 1; // choose number of connections in the range [1, 20]
            for (int j = 0; j < k; j++) {
                int r = rand() % total_degree; // choose node to connect to based on degree
                int l = 0, h = n - 1, mid;
                while (l <= h) { // binary search to find node
                    mid = (l + h) / 2;
                    if (probabilities[mid] < r) {
                        l = mid + 1;
                    } else if (mid == 0 || probabilities[mid - 1] < r) {
                        connections[j] = mid;
                        break;
                    } else {
                        h = mid - 1;
                    }
                }
            }
            for (int j = 0; j < k; j++) { // add connections
                graph->nodes[i].edges[graph->nodes[i].num_neighbors++] = connections[j];
                graph->nodes[connections[j]].edges[graph->nodes[connections[j]].num_neighbors++] = graph->nodes[i].id;
                degrees[i]++;
                degrees[connections[j]]++;
                total_degree += 2;
                probabilities[0] = degrees[0];
                for (int l = 1; l < n; l++) {
                    probabilities[l] = probabilities[l - 1] + degrees[l];
                }
            }
        }
        graph->num_nodes += m; // update number of nodes
    }

    return 0;
}